# 易播Linux后台服务器

## 开发环境搭建

### 预备程序

以下程序联系助教获取

* 虚拟机VMware和Ubuntu虚拟机
* Visual Studio 2019
* SimpleRemote（ssh工具）
* FileZilla（FTP文件传输工具）

### Visual Studio 2019的下载

首先打开https://visualstudio.microsoft.com/zh-hans/vs/older-downloads/

按照下图所示，展开2019栏目，点击下载

![](1.jpg)

注意，如果没有在微软注册账号，此时会弹出下图所示的对话框

![](2.jpg)

在上面输入账号（如果没有可以点击创建一个，使用qq邮箱创建一个）

输入账号之后，点击下一步，进入密码对话框

![](3.jpg)

然后输入密码，点击登录

成功登录之后，会提示你是否保持登录状态，勾选保持登录状态

接着会进入如下页面

![](4.jpg)

按照顺序点击页面中红色方框标记的位置，即可进入最终的下载页面

![](5.jpg)

注意1这里，一定要选择Community（社区）版本。

这个是官方免费正版的，和专业版（Professional）以及团队版（Team Explorer）差异并没有太大。

初学者强烈建议使用该版本！！！

第二个点就是语言，一定要使用多语言版本，否则界面可能不是中文的！

参考图中2标识的位置，进行选择

最后就可以点击下载了！

如果下载没有开始，并且长时间停留在这个页面，那么可以点击下图中的连接，再次激发下载

![](6.jpg)

可以看到下载界面

![](7.jpg)

下载完成后，点击程序开始安装

注意，不要随意修改安装路径

如果默认的C盘空间不足，**可以修改盘符，但是不要修改路径！！！**

2019的下载就介绍到这里，详细的安装过程，可以参考VS的安装视频。

### 虚拟机环境介绍

启动VMware Workstation之后，使用菜单里面**文件**→**打开**来打开虚拟机

![](8.jpg)

在弹出的窗口里面选择vmx文件

![](9.jpg)

注意，VM会问你虚拟机是哪里来的。一个是复制来的，一个是移动来的。

选择复制来的。

然后按照下图所示打开虚拟机设置

![](10.jpg)



在**硬件**→**网络适配器**→**桥接模式**设置网络，结果如下图：

![](11.jpg)

另外依据自己的机器调整**内存大小**和**处理器数量**

然后启动虚拟机，来到登录界面：

![](12.jpg)

点击ydy，输入密码ydy619619进行登录

登录后，大概是这个样子：

![](13.jpg)

点击左上角的网络按钮

![](14.jpg)

点击有线连接→有线设置

打开网络设置，点击下图所示按钮

![](15.jpg)

然后在网络设置页面查看ip

![](16.jpg)

**记下这个ip，后面会用到！！！**

如果这个IP和你自己主机的IP地址不在一个网段

可以IPv4页面进行修改，如下图

![](17.jpg)

至此虚拟机的IP已经拿到（或者设置完成）

请务必让虚拟机使用固定IP，否则后面会因为IP变化而导致各种设置失效

如果IP和局域网其他机器冲突，那么请调整IP地址，直到没有冲突产生

虚拟机成功启动之后，可以点击虚拟机右上角的关闭按钮，然后选择在后台运行

![](18.jpg)

如上图所示。

这样可以节约一定的系统资源。

### SimpleRemote的使用

![](19.jpg)

在任意目录建立一个SimpleRemote的文件夹

然后将SimpleRemote.exe复制到该文件夹，即完成SimpleRemote的安装

双击exe打开软件，右键单击，打开新建菜单，如下图：

![](20.jpg)

选择**SSH连接**

将前面我们记录下来的ip、账号和密码，按照下图进行填写：

![](21.jpg)

**记住，字符集那里要填写为utf-8**

否则后面中文显示可能会出现乱码！

然后双击标签栏，或者输入回车，即可进入ssh界面：

![](22.jpg)

输入`ls -l`命令

如果能够看到**中文显示的月字**，则表示一切正常，配置正确

如果需要关机，输入

`shutdown -P 0`

则虚拟机会在一分钟内（依据主机性能来决定，可能会超过一分钟）自动关闭。



后面我们就可以开始愉快的学习了！



### FileZilla的使用

通过FileZilla_3.58.0_win64-setup.exe安装文件，按照默认配置，安装好FileZilla之后，就可以启动FileZilla了

启动之后，在左上角，点击下图红色方框的按钮，即可打开连接配置（如下图）

![](23.jpg)

然后在我的站点，重命名站点为易播服务器。

右边选择SFTP，依次填入主机IP、用户、密码（`root`、`123456`）

然后点击连接即可进入工作模式：

![](24.jpg)

左边是本机地址，右边是远程的服务器地址。

可以将本地文件上传到服务器，也可以将远程的服务器文件下载到本地。

这个工具提供一个文件上传和下载的功能，非常方便。





## 项目的开发

前面我们已经搭建好了开发环境，安装好了开发软件。

下面我们就从零开始，一点点的把项目实现。

### 项目的创建

打开Visual Studio 2019

![](25.jpg)

选择右下角的**创建新项目**

然后选择C++、Linux、控制台里面的**控制台应用程序**

![](26.jpg)

然后点击下一步

如果你没有这个，请在开始菜单里面找到visual studio installer

![](27.jpg)

打开后，找到2019的社区版，点击修改：

![](28.jpg)

然后看看**使用C++的Linux开发**是否勾选：

![](29.jpg)

如果没有勾选，则勾选上，再重复前面的操作即可。

然后按照下图输入项目名称（**EPlayerServer**）和路径：

![](30.jpg)

然后点击创建按钮，即可进入项目目录

![](31.jpg)

到目前为止，我们的项目算是建立了。

但是开发环境还需要一些设置。

首先需要确保虚拟机已经打开，并且虚拟系统Ubuntu已经启动。

然后我们需要在**菜单**→**工具**→**选项**→**跨平台**→**连接管理器**

![](32.jpg)

点击**添加**按钮，进入远程连接界面：

![](33.jpg)

输入虚拟机的IP地址、用户名和密码，然后点击连接。

成功后，我们会看到如下内容：

![](34.jpg)

则表示成功。（注意，操作系统有可能识别不正确，但是对开发没有影响）

勾选我们新加的账户（默认那一排，让我们新加的账户处于上图状态即可）

点击确认按钮，回到项目页面

![](35.jpg)

点击**生成**下面的**生成解决方案**

![](36.jpg)

看到生成成功1个，则表示一切ok。

如果有错误，看看前面的操作是否存在问题，再运行一次。

然后点击下图所示的按钮：

![](37.jpg)

尝试运行程序。

看到下面的结果，则表示运行一切正常。

![](38.jpg)

返回值为0，程序返回值也为0，说明项目配置一切ok，我们就可以开始正式的代码开发了。

项目会在虚拟机系统里面的：

`/root/projects/EPlayerServer/bin/x64/Debug`

该路径也可以写作`~/projects/EPlayerServer/bin/x64/Debug`

下面。

我们登录SimpleRemote之后

可以通过`cd /root/projects/EPlayerServer/bin/x64/Debug`

命令进入该路径。

使用`ls -l`来查看目录下面的文件

使用`./EPlayerServer.out`来运行程序

过程如下图：

![](39.jpg)

我们可以在控制台看到中英文显示！

至此，项目建立完成，并且环境确认无误。我们就可以开始后面的项目开发啦！

### 进程和进程的创建

线程默认是进程内竞争，而进程是操作系统资源分配最小的调度单位。

这也就意味着，如果要充分利用系统资源，最好的形式是多线程多进程模式。

所以我们最好将一个整体功能，分散到多个进程之中，从而实现资源利用率的最大化。

否则就只能多个线程在一个进程内进行竞争，没法充分利用系统的资源。

毕竟多个进程竞争资源，比一个进程竞争资源，要有利得多。

下图是我们这个服务器项目要实现的进程结构图

```mermaid
graph TD
A[主进程] ==>B[网络服务器]
    A -.-> C((日志服务器))
    B ==> H[主进程结束]
    B -.-> D((客户端处理))
    D -.->E((数据库))
    F[进程关系图]
style A fill:#f00;
style B fill:#f00;
style H fill:#f00;
linkStyle 0,2 stroke:#00f,stroke-width:4px;
```



图中方框部分都是主进程模块，圆框则是子进程。

主进程只负责网络服务器部分，接入客户端，其他一概不管。

日志则由日志服务器进程来处理。

接入客户端之后，发送给客户端处理进程。

如果处理过程需要数据库，则和数据库进程进行交互。

这样，将一个进程完成的事情，分成了四个进程进行。

而且每个进程中可以依据自己的需求，开启多个线程来完成。



在Linux中，开启进程一般通过exec系列函数或者fork函数来完成。

即使是exec函数，也会要使用到fork函数。

所以开启进程，fork函数是无法绕开的。

而fork函数会对线程造成影响，所以我们一定要先定好进程结构，然后再开启线程。

<table><tr><td bgcolor=#FFC7C7>首先，由于线程无法被复制，所以在子进程中，一些线程会消失（没有被复制过来）</br>其次，如果程序逻辑依赖多线程模式的时候，fork可能在子进程中破坏掉这种模式，进而使得程序出现无法预料的问题。</br>所以一定要先准备好进程结构，再去使用线程！！！</td></tr></table>

由于数据库我们最后会使用MySQL，而MySQL进程是由第三方提供并随服务器启动而启动的服务程序。

所以我们最终要生成的进程是日志进程和客户端通信处理进程。

这意味着我们需要在一开始，就分离出两个子进程，分别处理日志和客户端

由于日志进程在后台服务器程序中的重要作用。

所以日志子进程应该优先创建，然后再创建客户端处理子进程。

所以整个进程的创建顺序，会按照进程关系图中所示顺序，进行创建。

```mermaid
sequenceDiagram
participant 主进程
participant 日志进程
participant 客户端进程
主进程->>主进程: 创建守护进程
主进程->>日志进程: 初始化函数
日志进程->>日志进程: 创建日志服务器
主进程->>客户端进程: 初始化函数
客户端进程->>客户端进程: 创建客户端处理线程池
```

### 进程模块的实现方案

创建进程的流程和结构，我们现在已经知道了。

但是如何实现，还有几个问题，需要我们一个一个去解决。

首先，每个子进程的逻辑并不一样，所需要的参数可能相互冲突。

那么如何满足这些需求呢？

其次，客户端处理进程，需要处理客户端。

我们这是一个网络程序，主进程接收到客户端之后，如何通知子进程去处理呢？

客户端这个时候是一个文件描述符，怎么告诉子进程去处理呢？

所以我们需要两个功能：

* 灵活的进程入口函数
* 进程间传递文件描述符

第二个功能我们稍后再说，我们先讲讲第一个功能

这个功能可以有三种做法：

1. **使用无属性的指针参数和固定参数的进程入口函数来实现**
2. **使用面向对象的参数和统一的进程入口函数来实现**
3. **使用模板函数来实现**

这三种方式都可以实现，但是方便程度和安全性不一样。

第一种方式**技术上最简单**，但是类型在转换的时候，可能出现问题。

而且可以传入的参数数量是固定的，以后其他项目很难复用此代码。

第二种方式比第一种好了不少。**参数不是固定的，可移植性强了很多**。

但是这种方式需要专门写一个参数封装和解析的代码。

这种解析代码的复用性会比较差。

因为每个进程的任务不一样，参数也不一样，参数的含义也可能大相径庭。

第三种方式难度最大，但是**使用起来最方便，可以移植性最强**。

参数可以随时修改，函数也可以是类的成员函数。

此外参数无需解析，直接原样转发到目标函数。

实现起来也不需要太多代码，stl里面准备好了很多工具，可以直接使用。

就是模板编程不太好理解。

我们这里将采取第三种方式来实现。

### 进程入口函数的实现

**fork函数介绍**

```c++
#include <unistd.h>
pid_t fork(void);
```

返回值：

主进程中，会返回子进程的pid。

子进程中，返回值为0。

如果失败，返回-1。





```mermaid
graph TD
A[CFunctionBase] -->|派生| B[CFunction]

```



```C++
#include <cstdio>

#include <unistd.h>
#include <functional>

class CFunctionBase
{
public:
	virtual ~CFunctionBase() {}
	virtual int operator()() = 0;
};

template<typename _FUNCTION_, typename... _ARGS_>
class CFunction :public CFunctionBase
{
public:
	CFunction(_FUNCTION_ func, _ARGS_... args) {
	}
	virtual ~CFunction() {}
	virtual int operator()() {
		return m_binder();
	}
	std::_Bindres_helper<int, _FUNCTION_, _ARGS_...>::type m_binder;
};

class CProcess
{
public:
	CProcess() {
		m_func = NULL;
	}
	~CProcess() {
		if (m_func != NULL) {
			delete m_func;
			m_func = NULL;
		}
	}

	template<typename _FUNCTION_, typename... _ARGS_>
	int SetEntryFunction(_FUNCTION_ func, _ARGS_... args)
	{
		m_func = new CFunction(func, args...);
		return 0;
	}

	int CreateSubProcess() {
		if (m_func == NULL)return -1;
		pid_t pid = fork();
		if (pid == -1)return -2;
		if (pid == 0) {
			//子进程
			return (*m_func)();
		}
		//主进程
		m_pid = pid;
		return 0;
	}

private:
	CFunctionBase* m_func;
	pid_t m_pid;
};


int CreateLogServer(CProcess* proc)
{
	return 0;
}

int CreateClientServer(CProcess* proc)
{
	return 0;
}

int main()
{
	CProcess proclog,proccliets;
	proclog.SetEntryFunction(CreateLogServer, &proclog);
	int ret = proclog.CreateSubProcess();
	proccliets.SetEntryFunction(CreateClientServer, &proccliets);
	ret = proccliets.CreateSubProcess();
	return 0;
}
```

### 进程间文件描述符的实现

```c++
#include <unistd.h>
#include <sys/types.h>
#include <functional>
#include <memory.h>
#include <sys/socket.h>


class CFunctionBase
{
public:
	virtual ~CFunctionBase() {}
	virtual int operator()() = 0;
};

template<typename _FUNCTION_, typename... _ARGS_>
class CFunction :public CFunctionBase
{
public:
	CFunction(_FUNCTION_ func, _ARGS_... args)
		:m_binder(std::forward<_FUNCTION_>(func), std::forward<_ARGS_>(args)...)
	{}
	virtual ~CFunction() {}
	virtual int operator()() {
		return m_binder();
	}
	typename std::_Bindres_helper<int, _FUNCTION_, _ARGS_...>::type m_binder;
};

class CProcess
{
public:
	CProcess() {
		m_func = NULL;
		memset(pipes, 0, sizeof(pipes));
	}
	~CProcess() {
		if (m_func != NULL) {
			delete m_func;
			m_func = NULL;
		}
	}

	template<typename _FUNCTION_, typename... _ARGS_>
	int SetEntryFunction(_FUNCTION_ func, _ARGS_... args)
	{
		m_func = new CFunction<_FUNCTION_, _ARGS_...>(func, args...);
		return 0;
	}

	int CreateSubProcess() {
		if (m_func == NULL)return -1;
		int ret = socketpair(AF_LOCAL, SOCK_STREAM, 0, pipes);
		if (ret == -1)return -2;
		pid_t pid = fork();
		if (pid == -1)return -3;
		if (pid == 0) {
			//子进程
			close(pipes[1]);//关闭掉写
			pipes[1] = 0;
			return (*m_func)();
		}
		//主进程
		close(pipes[0]);
		pipes[0] = 0;
		m_pid = pid;
		return 0;
	}

	int SendFD(int fd) {//主进程完成
		struct msghdr msg;
		iovec iov[2];
		iov[0].iov_base = (char*)"edoyun";
		iov[0].iov_len = 7;
		iov[1].iov_base = (char*)"jueding";
		iov[1].iov_len = 8;
		msg.msg_iov = iov;
		msg.msg_iovlen = 2;

		// 下面的数据，才是我们需要传递的。
		cmsghdr* cmsg = (cmsghdr*)calloc(1, CMSG_LEN(sizeof(int)));
		if (cmsg == NULL)return -1;
		cmsg->cmsg_len = CMSG_LEN(sizeof(int));
		cmsg->cmsg_level = SOL_SOCKET;
		cmsg->cmsg_type = SCM_RIGHTS;
		*(int*)CMSG_DATA(cmsg) = fd;
		msg.msg_control = cmsg;
		msg.msg_controllen = cmsg->cmsg_len;

		ssize_t ret = sendmsg(pipes[1], &msg, 0);
		free(cmsg);
		if (ret == -1) {
			return -2;
		}
		return 0;
	}

	int RecvFD(int& fd)
	{
		msghdr msg;
		iovec iov[2];
		char buf[][10] = { "","" };
		iov[0].iov_base = buf[0];
		iov[0].iov_len = sizeof(buf[0]);
		iov[1].iov_base = buf[1];
		iov[1].iov_len = sizeof(buf[1]);
		msg.msg_iov = iov;
		msg.msg_iovlen = 2;

		cmsghdr* cmsg = (cmsghdr*)calloc(1, CMSG_LEN(sizeof(int)));
		if (cmsg == NULL)return -1;
		cmsg->cmsg_len = CMSG_LEN(sizeof(int));
		cmsg->cmsg_level = SOL_SOCKET;
		cmsg->cmsg_type = SCM_RIGHTS;
		msg.msg_control = cmsg;
		msg.msg_controllen = CMSG_LEN(sizeof(int));
		ssize_t ret = recvmsg(pipes[0], &msg, 0);
		if (ret == -1) {
			free(cmsg);
			return -2;
		}
		fd = *(int*)CMSG_DATA(cmsg);
		return 0;
	}


private:
	CFunctionBase* m_func;
	pid_t m_pid;
	int pipes[2];
};
```

### 进程代码测试

测试点的设置：

* 进程分离
* 文件描述符传递

关键点如下图

```mermaid
graph TD
A[主进程] ==调用==>B[网络服务器]
    A -.测试点.-> C((日志服务器))
    B ==调用==> H[主进程结束]
    B -.测试点.-> D((客户端处理))
    G>测试文件描述符传递] -.- D
    D -.网络调用.->E((数据库))
    F[进程关系图]
style A fill:#f00;
style B fill:#f00;
style H fill:#f00;
style G fill:#0f0,stroke-dasharray:5,5;
linkStyle 0,2 stroke:#00f,stroke-width:4px;
linkStyle 4 stroke:#0f0,stroke-width:3px,stroke-dasharray:3,3;
```

测试代码如下：

```c++
#include <cstdio>

#include <unistd.h>
#include <sys/types.h>
#include <functional>
#include <memory.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>


class CFunctionBase
{
public:
	virtual ~CFunctionBase() {}
	virtual int operator()() = 0;
};

template<typename _FUNCTION_, typename... _ARGS_>
class CFunction :public CFunctionBase
{
public:
	CFunction(_FUNCTION_ func, _ARGS_... args)
		:m_binder(std::forward<_FUNCTION_>(func), std::forward<_ARGS_>(args)...)
	{}
	virtual ~CFunction() {}
	virtual int operator()() {
		return m_binder();
	}
	typename std::_Bindres_helper<int, _FUNCTION_, _ARGS_...>::type m_binder;
};

class CProcess
{
public:
	CProcess() {
		m_func = NULL;
		memset(pipes, 0, sizeof(pipes));
	}
	~CProcess() {
		if (m_func != NULL) {
			delete m_func;
			m_func = NULL;
		}
	}

	template<typename _FUNCTION_, typename... _ARGS_>
	int SetEntryFunction(_FUNCTION_ func, _ARGS_... args)
	{
		m_func = new CFunction<_FUNCTION_, _ARGS_...>(func, args...);
		return 0;
	}

	int CreateSubProcess() {
		if (m_func == NULL)return -1;
		int ret = socketpair(AF_LOCAL, SOCK_STREAM, 0, pipes);
		if (ret == -1)return -2;
		pid_t pid = fork();
		if (pid == -1)return -3;
		if (pid == 0) {
			//子进程
			close(pipes[1]);//关闭掉写
			pipes[1] = 0;
			ret = (*m_func)();
			exit(0);
		}
		//主进程
		close(pipes[0]);
		pipes[0] = 0;
		m_pid = pid;
		return 0;
	}

	int SendFD(int fd) {//主进程完成
		struct msghdr msg;
		iovec iov[2];
		char buf[2][10] = { "edoyun","jueding" };
		iov[0].iov_base = buf[0];
		iov[0].iov_len = sizeof(buf[0]);
		iov[1].iov_base = buf[1];
		iov[1].iov_len = sizeof(buf[1]);
		msg.msg_iov = iov;
		msg.msg_iovlen = 2;

		// 下面的数据，才是我们需要传递的。
		cmsghdr* cmsg = (cmsghdr*)calloc(1, CMSG_LEN(sizeof(int)));
		if (cmsg == NULL)return -1;
		cmsg->cmsg_len = CMSG_LEN(sizeof(int));
		cmsg->cmsg_level = SOL_SOCKET;
		cmsg->cmsg_type = SCM_RIGHTS;
		*(int*)CMSG_DATA(cmsg) = fd;
		msg.msg_control = cmsg;
		msg.msg_controllen = cmsg->cmsg_len;

		ssize_t ret = sendmsg(pipes[1], &msg, 0);
		free(cmsg);
		if (ret == -1) {
			return -2;
		}
		return 0;
	}

	int RecvFD(int& fd)
	{
		msghdr msg;
		iovec iov[2];
		char buf[][10] = { "","" };
		iov[0].iov_base = buf[0];
		iov[0].iov_len = sizeof(buf[0]);
		iov[1].iov_base = buf[1];
		iov[1].iov_len = sizeof(buf[1]);
		msg.msg_iov = iov;
		msg.msg_iovlen = 2;

		cmsghdr* cmsg = (cmsghdr*)calloc(1, CMSG_LEN(sizeof(int)));
		if (cmsg == NULL)return -1;
		cmsg->cmsg_len = CMSG_LEN(sizeof(int));
		cmsg->cmsg_level = SOL_SOCKET;
		cmsg->cmsg_type = SCM_RIGHTS;
		msg.msg_control = cmsg;
		msg.msg_controllen = CMSG_LEN(sizeof(int));
		ssize_t ret = recvmsg(pipes[0], &msg, 0);
		if (ret == -1) {
			free(cmsg);
			return -2;
		}
		fd = *(int*)CMSG_DATA(cmsg);
		free(cmsg);
		return 0;
	}


private:
	CFunctionBase* m_func;
	pid_t m_pid;
	int pipes[2];
};


int CreateLogServer(CProcess* proc)
{
	printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
	return 0;
}

int CreateClientServer(CProcess* proc)
{
	printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
	int fd = -1;
	int ret = proc->RecvFD(fd);
	printf("%s(%d):<%s> ret=%d\n", __FILE__, __LINE__, __FUNCTION__, ret);
	printf("%s(%d):<%s> fd=%d\n", __FILE__, __LINE__, __FUNCTION__, fd);
	sleep(1);
	char buf[10] = "";
	lseek(fd, 0, SEEK_SET);
	read(fd, buf, sizeof(buf));
	printf("%s(%d):<%s> buf=%s\n", __FILE__, __LINE__, __FUNCTION__, buf);
	close(fd);
	return 0;
}

int main()
{
	CProcess proclog, procclients;
	printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
	proclog.SetEntryFunction(CreateLogServer, &proclog);
	int ret = proclog.CreateSubProcess();
	if (ret != 0) {
		printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
		return -1;
	}
	printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
	procclients.SetEntryFunction(CreateClientServer, &procclients);
	ret = procclients.CreateSubProcess();
	if (ret != 0) {
		printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
		return -2;
	}
	printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
	usleep(100 * 000);
	int fd = open("./test.txt", O_RDWR | O_CREAT | O_APPEND);
	printf("%s(%d):<%s> fd=%d\n", __FILE__, __LINE__, __FUNCTION__, fd);
	if (fd == -1)return -3;
	ret = procclients.SendFD(fd);
	printf("%s(%d):<%s> ret=%d\n", __FILE__, __LINE__, __FUNCTION__, ret);
	if (ret != 0)printf("errno:%d msg:%s\n", errno, strerror(errno));
	write(fd, "edoyun", 6);
	close(fd);
	return 0;
}
```



### 守护进程的实现

守护进程的流程

```mermaid
graph TD
A(开始) --> B[fork]
subgraph 主进程
B --> Z
end
subgraph 子进程
B --> D[setsid成为会话组长]
D --> E[fork]
E --> F(结束)
end
subgraph 孙进程
E --> G[close关闭标准输入输出]
G --> H[chdir修改当前目录]
H --> I[umask清除文件遮蔽位]
I --> J[signal处理SIGCHILD信号]
J --> K[主程序...]
K --> L(结束)
end

Z(结束)   
X[守护进程流程图]
```



守护进程实现代码如下：

```c++
static int SwitchDeamon() {
		pid_t ret = fork();
		if (ret == -1)return -1;
		if (ret > 0)exit(0);//主进程到此为止
		//子进程内容如下
		ret = setsid();
		if (ret == -1)return -2;//失败，则返回
		ret = fork();
		if (ret == -1)return -3;
		if (ret > 0)exit(0);//子进程到此为止
		//孙进程的内容如下，进入守护状态
		for (int i = 0; i < 3; i++) close(i);
		umask(0);
		signal(SIGCHLD, SIG_IGN);
		return 0;
	}
```



### 日志模块的设计

现在我们一开始就是多进程模式了，所以直接就可以上进程间通信。

进程间通信，最方便最快速的就是**本地套接字**通信了。

* 文件通信磁盘速度慢

* 管道在多线程环境下不太方便（可能会出现内容插入）而且是**单向**的。

* 信号量**信息量太少**
* 内存共享需要反复加锁同步，否则可能出现问题
* 消息函数（sendmsg、recvmsg）需要创建时确定
* 网络套接字通信，需要额外的IP和端口

所以本地套接字是最佳选择

* 无需IP和端口，不影响服务器对外的资源
* 信息无需加锁，可以多线程并发写
* 数据传输量巨大，传输速率高（纯内存读写）

日志模块的设计图

```mermaid
graph TD
A(开始) --> B[客户端初始化]
B --> C[日志服务器初始化]
B --> F[发送日志]
subgraph 日志服务器进程
C --> D[接收日志]
end
F -.日志信息.-> D
Z[日志模块设计图]
```



### Epoll的封装

epoll简单模型

```mermaid
graph TD
A[epoll_create]--> E[创建线程]
subgraph 主线程
E-->B0[epoll_ctl EPOLL_CTL_ADD]
E-->B1[epoll_ctl EPOLL_CTL_MOD]
E-->B2[epoll_ctl EPOLL_CTL_DEL]
B0-->D[close]
B1-->D
B2-->D
end
subgraph 子线程
E-->C[epoll_wait]
C-->F[处理事件]
F-->C
end



```

接口：

```c++
#pragma once
#include <unistd.h>
#include <sys/epoll.h>
#include <vector>
#include <errno.h>
#include <sys/signal.h>
#include <memory.h>

#define EVENT_SIZE  128
class EpollData
{
public:
	EpollData() { m_data.u64 = 0; }
	EpollData(void* ptr) { m_data.ptr = ptr; }
	explicit EpollData(int fd) { m_data.fd = fd; }
	explicit EpollData(uint32_t u32) { m_data.u32 = u32; }
	explicit EpollData(uint64_t u64) { m_data.u64 = u64; }
	EpollData(const EpollData& data) { m_data.u64 = data.m_data.u64; }
public:
	EpollData& operator=(const EpollData& data) {
		if (this != &data)
			m_data.u64 = data.m_data.u64;
		return *this;
	}
	EpollData& operator=(void* data) {
		m_data.ptr = data;
		return *this;
	}
	EpollData& operator=(int data) {
		m_data.fd = data;
		return *this;
	}
	EpollData& operator=(uint32_t data) {
		m_data.u32 = data;
		return *this;
	}
	EpollData& operator=(uint64_t data) {
		m_data.u64 = data;
		return *this;
	}
	operator epoll_data_t() { return m_data; }
	operator epoll_data_t()const { return m_data; }
	operator epoll_data_t* () { return &m_data; }
	operator const epoll_data_t* ()const { return &m_data; }
private:
	epoll_data_t m_data;
};

using EPEvents = std::vector<epoll_event>;

class CEpoll
{
public:
	CEpoll() {
		m_epoll = -1;
	}
	~CEpoll() {
		Close();
	}
public:
	CEpoll(const CEpoll&) = delete;
	CEpoll& operator=(const CEpoll&) = delete;
public:
	operator int()const { return m_epoll; }
public:
	int Create(unsigned count) {
		if (m_epoll != -1)return -1;
		m_epoll = epoll_create(count);
		if (m_epoll == -1)return -2;
		return 0;
	}
	//小于0表示错误 等于0表示没有事情发生 大于0表示成功拿到事件
	ssize_t WaitEvents(EPEvents& events, int timeout = 10) {
		if (m_epoll == -1)return -1;
		EPEvents evs(EVENT_SIZE);
		int ret = epoll_wait(m_epoll, evs.data(), (int)evs.size(), timeout);
		if (ret == -1) {
			if ((errno == EINTR) || (errno == EAGAIN)) {
				return 0;
			}
			return -2;
		}
		if (ret > (int)events.size()) {
			events.resize(ret);
		}
		memcpy(events.data(), evs.data(), sizeof(epoll_event) * ret);
		return ret;
	}
	int Add(int fd, const EpollData& data = EpollData((void*)0), uint32_t events = EPOLLIN)
	{
		if (m_epoll == -1)return -1;
		epoll_event ev = { events,data };
		int ret = epoll_ctl(m_epoll, EPOLL_CTL_ADD, fd, &ev);
		if (ret == -1)return -2;
		return 0;
	}
	int Modify(int fd, uint32_t events, const EpollData& data = EpollData((void*)0))
	{
		if (m_epoll == -1)return -1;
		epoll_event ev = { events,data };
		int ret = epoll_ctl(m_epoll, EPOLL_CTL_MOD, fd, &ev);
		if (ret == -1)return -2;
		return 0;
	}
	int Del(int fd)
	{
		if (m_epoll == -1)return -1;
		int ret = epoll_ctl(m_epoll, EPOLL_CTL_DEL, fd, NULL);
		if (ret == -1)return -2;
		return 0;
	}
	void Close() {
		if (m_epoll != -1) {
			int fd = m_epoll;
			m_epoll = -1;
			close(fd);
		}
	}

private:
	int m_epoll;
};
```



### 进程间通信的实现

本地套接字的封装

```mermaid
graph TD
subgraph 客户端
A0[创建套接字]-->A1[connect]
A1-->A2[recv]
A1-->A3[send]
A2-->A4[关闭套接字]
A3-->A4
end
subgraph 服务端
B0[创建套接字]-->B1[bind]
B1-->B5[listen]
B5-->B6[accept]
B6-->B2[recv]
B6-->B3[send]
B2-->B4[关闭套接字]
B3-->B4
end
A1 -.网络通信.- B6
style A0 fill:#f9f
style B0 fill:#f9f
style B1 fill:#f9f
style B5 fill:#f9f
style A1 fill:#88f
style B6 fill:#88f
style B2 fill:#8f8
style A2 fill:#8f8
style B3 fill:#f88
style A3 fill:#f88
```



```C++
#pragma once
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string>
#include <fcntl.h>

class Buffer :public std::string
{
public:
	Buffer() :std::string() {}
	Buffer(size_t size) :std::string() { resize(size); }
	operator char* () { return (char*)c_str(); }
	operator char* () const { return (char*)c_str(); }
	operator const char* () const { return c_str(); }
};

enum SockAttr {
	SOCK_ISSERVER = 1,//是否服务器 1表示是 0表示客户端
	SOCK_ISNONBLOCK = 2,//是否阻塞 1表示非阻塞 0表示阻塞
	SOCK_ISUDP = 4,//是否为UDP 1表示udp 0表示tcp
};

class CSockParam {
public:
	CSockParam() {
		bzero(&addr_in, sizeof(addr_in));
		bzero(&addr_un, sizeof(addr_un));
		port = -1;
		attr = 0;//默认是客户端、阻塞、tcp
	}
	CSockParam(const Buffer& ip, short port, int attr) {
		this->ip = ip;
		this->port = port;
		this->attr = attr;
		addr_in.sin_family = AF_INET;
		addr_in.sin_port = port;
		addr_in.sin_addr.s_addr = inet_addr(ip);
	}
	CSockParam(const Buffer& path, int attr) {
		ip = path;
		addr_un.sun_family = AF_UNIX;
		strcpy(addr_un.sun_path, path);
		this->attr = attr;
	}
	~CSockParam() {}
	CSockParam(const CSockParam& param) {
		ip = param.ip;
		port = param.port;
		attr = param.attr;
		memcpy(&addr_in, &param.addr_in, sizeof(addr_in));
		memcpy(&addr_un, &param.addr_un, sizeof(addr_un));
	}
public:
	CSockParam& operator=(const CSockParam& param) {
		if (this != &param) {
			ip = param.ip;
			port = param.port;
			attr = param.attr;
			memcpy(&addr_in, &param.addr_in, sizeof(addr_in));
			memcpy(&addr_un, &param.addr_un, sizeof(addr_un));
		}
		return *this;
	}
	sockaddr* addrin() { return (sockaddr*)&addr_in; }
	sockaddr* addrun() { return (sockaddr*)&addr_un; }
public:
	//地址
	sockaddr_in addr_in;
	sockaddr_un addr_un;
	//ip
	Buffer ip;
	//端口
	short port;
	//参考SockAttr
	int attr;
};

class CSocketBase
{
public:
	CSocketBase() {
		m_socket = -1;
		m_status = 0;//初始化未完成
	}
	//传递析构操作
	virtual ~CSocketBase() {
		Close();
	}
public:
	//初始化 服务器 套接字创建、bind、listen  客户端 套接字创建
	virtual int Init(const CSockParam& param) = 0;
	//连接 服务器 accept 客户端 connect  对于udp这里可以忽略
	virtual int Link(CSocketBase** pClient = NULL) = 0;
	//发送数据
	virtual int Send(const Buffer& data) = 0;
	//接收数据
	virtual int Recv(Buffer& data) = 0;
	//关闭连接
	virtual int Close() {
		m_status = 3;
		if (m_socket != -1) {
			int fd = m_socket;
			m_socket = -1;
			close(fd);
		}
	};
protected:
	//套接字描述符，默认是-1
	int m_socket;
	//状态 0初始化未完成 1初始化完成 2连接完成 3已经关闭
	int m_status;
	//初始化参数
	CSockParam m_param;
};

class CLocalSocket
	:public CSocketBase
{
public:
	CLocalSocket() :CSocketBase() {}
	CLocalSocket(int sock) :CSocketBase() {
		m_socket = sock;
	}
	//传递析构操作
	virtual ~CLocalSocket() {
		Close();
	}
public:
	//初始化 服务器 套接字创建、bind、listen  客户端 套接字创建
	virtual int Init(const CSockParam& param) {
		if (m_status != 0)return -1;
		m_param = param;
		int type = (m_param.attr & SOCK_ISUDP) ? SOCK_DGRAM : SOCK_STREAM;
		if (m_socket == -1)
			m_socket = socket(PF_LOCAL, type, 0);
		if (m_socket == -1)return -2;
		int ret = 0;
		if (m_param.attr & SOCK_ISSERVER) {
			ret = bind(m_socket, m_param.addrun(), sizeof(sockaddr_un));
			if (ret == -1) return -3;
			ret = listen(m_socket, 32);
			if (ret == -1)return -4;
		}
		if (m_param.attr & SOCK_ISNONBLOCK) {
			int option = fcntl(m_socket, F_GETFL);
			if (option == -1)return -5;
			option |= O_NONBLOCK;
			ret = fcntl(m_socket, F_SETFL, option);
			if (ret == -1)return -6;
		}
		m_status = 1;
		return 0;
	}
	//连接 服务器 accept 客户端 connect  对于udp这里可以忽略
	virtual int Link(CSocketBase** pClient = NULL) {
		if (m_status <= 0 || (m_socket == -1))return -1;
		int ret = 0;
		if (m_param.attr & SOCK_ISSERVER) {
			if (pClient == NULL)return -2;
			CSockParam param;
			socklen_t len = sizeof(sockaddr_un);
			int fd = accept(m_socket, param.addrun(), &len);
			if (fd == -1)return -3;
			*pClient = new CLocalSocket(fd);
			if (*pClient == NULL)return -4;
			ret = (*pClient)->Init(param);
			if (ret != 0) {
				delete (*pClient);
				*pClient = NULL;
				return -5;
			}
		}
		else {
			ret = connect(m_socket, m_param.addrun(), sizeof(sockaddr_un));
			if (ret != 0)return -6;
		}
		m_status = 2;
		return 0;
	}
	//发送数据
	virtual int Send(const Buffer& data) {
		if (m_status < 2 || (m_socket == -1))return -1;
		ssize_t index = 0;
		while (index < (ssize_t)data.size()) {
			ssize_t len = write(m_socket, (char*)data + index, data.size() - index);
			if (len == 0)return -2;
			if (len < 0)return -3;
			index += len;
		}
		return 0;
	}
	//接收数据 大于零，表示接收成功 小于 表示失败 等于0 表示没有收到数据，但没有错误
	virtual int Recv(Buffer& data) {
		if (m_status < 2 || (m_socket == -1))return -1;
		ssize_t len = read(m_socket, data, data.size());
		if (len > 0) {
			data.resize(len);
			return (int)len;//收到数据
		}
		if (len < 0) {
			if (errno == EINTR || (errno == EAGAIN)) {
				data.clear();
				return 0;//没有数据收到
			}
			return -2;//发送错误
		}
		return -3;//套接字被关闭
	}
	//关闭连接
	virtual int Close() {
		return CSocketBase::Close();
	}
};
```

### 线程的封装

静态函数到非静态函数的转换

```mermaid
graph TD
A0[pthread_create 系统 附带this指针]-->A1[CThread::ThreadEntry 静态 参数是this指针]
A1-->A2[CThread::EnterThread 成员]
```



Thread.h

```c++
#pragma once
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <signal.h>
#include <map>
#include "Function.h"


class CThread
{
public:
	CThread() {
		m_function = NULL;
		m_thread = 0;
		m_bpaused = false;
	}

	template<typename _FUNCTION_, typename... _ARGS_>
	CThread(_FUNCTION_ func, _ARGS_... args)
		:m_function(new CFunction<_FUNCTION_, _ARGS_...>(func, args...))
	{
		m_thread = 0;
		m_bpaused = false;
	}

	~CThread() {}
public:
	CThread(const CThread&) = delete;
	CThread operator=(const CThread&) = delete;
public:
	template<typename _FUNCTION_, typename... _ARGS_>
	int SetThreadFunc(_FUNCTION_ func, _ARGS_... args)
	{
		m_function = new CFunction<_FUNCTION_, _ARGS_...>(func, args...);
		if (m_function == NULL)return -1;
		return 0;
	}
	int Start() {
		pthread_attr_t attr;
		int ret = 0;
		ret = pthread_attr_init(&attr);
		if (ret != 0)return -1;
		ret = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
		if (ret != 0)return -2;
		ret = pthread_attr_setscope(&attr, PTHREAD_SCOPE_PROCESS);
		if (ret != 0)return -3;
		ret = pthread_create(&m_thread, &attr, &CThread::ThreadEntry, this);
		if (ret != 0)return -4;
		m_mapThread[m_thread] = this;
		ret = pthread_attr_destroy(&attr);
		if (ret != 0)return -5;
		return 0;
	}
	int Pause() {
		if (m_thread != 0)return -1;
		if (m_bpaused) {
			m_bpaused = false;
			return 0;
		}
		m_bpaused = true;
		int ret = pthread_kill(m_thread, SIGUSR1);
		if (ret != 0) {
			m_bpaused = false;
			return -2;
		}
		return 0;
	}
	int Stop() {
		if (m_thread != 0) {
			pthread_t thread = m_thread;
			m_thread = 0;
			timespec ts;
			ts.tv_sec = 0;
			ts.tv_nsec = 100 * 1000000;//100ms
			int ret = pthread_timedjoin_np(thread, NULL, &ts);
			if (ret == ETIMEDOUT) {
				pthread_detach(thread);
				pthread_kill(thread, SIGUSR2);
			}
		}
		return 0;
	}
	bool isValid()const { return m_thread == 0; }
private:
	//__stdcall
	static void* ThreadEntry(void* arg) {
		CThread* thiz = (CThread*)arg;
		struct sigaction act = { 0 };
		sigemptyset(&act.sa_mask);
		act.sa_flags = SA_SIGINFO;
		act.sa_sigaction = &CThread::Sigaction;
		sigaction(SIGUSR1, &act, NULL);
		sigaction(SIGUSR2, &act, NULL);

		thiz->EnterThread();

		if (thiz->m_thread)thiz->m_thread = 0;
		pthread_t thread = pthread_self();//不是冗余，有可能被stop函数把m_thread给清零了
		auto it = m_mapThread.find(thread);
		if (it != m_mapThread.end())
			m_mapThread[thread] = NULL;
		pthread_detach(thread);
		pthread_exit(NULL);
	}

	static void Sigaction(int signo, siginfo_t* info, void* context)
	{
		if (signo == SIGUSR1) {
			pthread_t thread = pthread_self();
			auto it = m_mapThread.find(thread);
			if (it != m_mapThread.end()) {
				if (it->second) {
					while (it->second->m_bpaused) {
						if (it->second->m_thread == 0) {
							pthread_exit(NULL);
						}
						usleep(1000);//1ms
					}
				}
			}
		}
		else if (signo == SIGUSR2) {//线程退出
			pthread_exit(NULL);
		}
	}

	void EnterThread() {//__thiscall
		if (m_function != NULL) {
			int ret = (*m_function)();
			if (ret != 0) {
				printf("%s(%d):[%s]ret = %d\n", __FILE__, __LINE__, __FUNCTION__);
			}
		}
	}
private:
	CFunctionBase* m_function;
	pthread_t m_thread;
	bool m_bpaused;//true 表示暂停 false表示运行中
	static std::map<pthread_t, CThread*> m_mapThread;
};
```

Thread.cpp

```c++
#include "Thread.h"

std::map<pthread_t, CThread*> CThread::m_mapThread;
```



### 日志模块的实现

日志工作时序图

```mermaid
sequenceDiagram
participant main
participant CProcess
participant CLogServer
participant CThread
participant CEpoll
participant CSocketBase
participant CLocalSocket
main->>CProcess:SetEntryFunction()
main->>CProcess:CreateSubProcess()
main->>main:CreateLogServer()
main->>CLogServer:Start()
CLogServer->>CEpoll:Create()
CLogServer->>CSocketBase:Init()
CSocketBase->>CLocalSocket:Init()
CLogServer->>CThread:Start()
CThread->>CLogServer:ThreadFunc()
CLogServer->>CEpoll:WaitEvents()
CLogServer->>CSocketBase:Send()
CSocketBase->>CLocalSocket:Send()
CLogServer->>CSocketBase:Recv()
CSocketBase->>CLocalSocket:Recv()
main->>CLogServer:Trace()
```

```c++
#pragma once
#include "Thread.h"
#include "Epoll.h"
#include "Socket.h"
#include <list>
#include <sys/timeb.h>
#include <stdarg.h>
#include <sstream>
#include <sys/stat.h>

enum LogLevel {
	LOG_INFO,
	LOG_DEBUG,
	LOG_WARNING,
	LOG_ERROR,
	LOG_FATAL
};

class LogInfo {
public:
	LogInfo(
		const char* file, int line, const char* func,
		pid_t pid, pthread_t tid, int level,
		const char* fmt, ...);
	LogInfo(
		const char* file, int line, const char* func,
		pid_t pid, pthread_t tid, int level);
	
	LogInfo(const char* file, int line, const char* func,
		pid_t pid, pthread_t tid, int level,
		void* pData, size_t nSize);
	
	~LogInfo();
	operator Buffer()const {
		return m_buf;
	}
	template<typename T>
	LogInfo& operator<<(const T& data) {
		std::stringstream stream;
		stream << data;
		m_buf += stream.str();
		return *this;
	}
private:
	bool bAuto;//默认是false 流式日志，则为true
	Buffer m_buf;
};

class CLoggerServer
{
public:
	CLoggerServer() :
		m_thread(&CLoggerServer::ThreadFunc, this)
	{
		m_server = NULL;
		m_path = "./log/" + GetTimeStr() + ".log";
		printf("%s(%d):[%s]path=%s\n", __FILE__, __LINE__, __FUNCTION__, (char*)m_path);
	}
	~CLoggerServer() {
		Close();
	}
public:
	CLoggerServer(const CLoggerServer&) = delete;
	CLoggerServer& operator=(const CLoggerServer&) = delete;
public:
	//日志服务器的启动
	int Start() {
		if (m_server != NULL)return -1;
		if (access("log", W_OK | R_OK) != 0) {
			mkdir("log", S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
		}
		m_file = fopen(m_path, "w+");
		if (m_file == NULL)return -2;
		int ret = m_epoll.Create(1);
		if (ret != 0)return -3;
		m_server = new CLocalSocket();
		if (m_server == NULL) {
			Close();
			return -4;
		}
		ret = m_server->Init(CSockParam("./log/server.sock", (int)SOCK_ISSERVER));
		if (ret != 0) {
			Close();
			return -5;
		}
		ret = m_thread.Start();
		if (ret != 0) {
			Close();
			return -6;
		}
		return 0;
	}
	int ThreadFunc() {
		EPEvents events;
		std::map<int, CSocketBase*> mapClients;
		while (m_thread.isValid() && (m_epoll != -1) && (m_server != NULL)) {
			ssize_t ret = m_epoll.WaitEvents(events, 1);
			if (ret < 0)break;
			if (ret > 0) {
				ssize_t i = 0;
				for (; i < ret; i++) {
					if (events[i].events & EPOLLERR) {
						break;
					}
					else if (events[i].events & EPOLLIN) {
						if (events[i].data.ptr == m_server) {
							CSocketBase* pClient = NULL;
							int r = m_server->Link(&pClient);
							if (r < 0) continue;
							r = m_epoll.Add(*pClient, EpollData((void*)pClient), EPOLLIN | EPOLLERR);
							if (r < 0) {
								delete pClient;
								continue;
							}
							auto it = mapClients.find(*pClient);
							if (it->second != NULL) {
								delete it->second;
							}
							mapClients[*pClient] = pClient;
						}
						else {
							CSocketBase* pClient = (CSocketBase*)events[i].data.ptr;
							if (pClient != NULL) {
								Buffer data(1024 * 1024);
								int r = pClient->Recv(data);
								if (r <= 0) {
									delete pClient;
									mapClients[*pClient] = NULL;
								}
								else {
									WriteLog(data);
								}
							}
						}
					}
				}
				if (i != ret) {
					break;
				}
			}
		}
		for (auto it = mapClients.begin(); it != mapClients.end(); it++) {
			if (it->second) {
				delete it->second;
			}
		}
		mapClients.clear();
		return 0;
	}
	int Close() {
		if (m_server != NULL) {
			CSocketBase* p = m_server;
			m_server = NULL;
			delete p;
		}
		m_epoll.Close();
		m_thread.Stop();
		return 0;
	}
	//给其他非日志进程的进程和线程使用的
	static void Trace(const LogInfo& info) {
		static thread_local CLocalSocket client;
		if (client == -1) {
			int ret = 0;
			ret = client.Init(CSockParam("./log/server.sock", 0));
			if (ret != 0) {
#ifdef _DEBUG
				printf("%s(%d):[%s]ret=%d\n", __FILE__, __LINE__, __FUNCTION__, ret);
#endif
				return;
			}
		}
		client.Send(info);
	}
	static Buffer GetTimeStr() {
		Buffer result(128);
		timeb tmb;
		ftime(&tmb);
		tm* pTm = localtime(&tmb.time);
		int nSize = snprintf(result, result.size(),
			"%04d-%02d-%02d %02d-%02d-%02d %03d",
			pTm->tm_year + 1900, pTm->tm_mon + 1, pTm->tm_mday,
			pTm->tm_hour, pTm->tm_min, pTm->tm_sec,
			tmb.millitm
		);
		result.resize(nSize);
		return result;
	}
private:
	void WriteLog(const Buffer& data) {
		if (m_file != NULL) {
			FILE* pFile = m_file;
			fwrite((char*)data, 1, data.size(), pFile);
			fflush(pFile);
#ifdef _DEBUG
			printf("%s", (char*)data);
#endif
		}
	}
private:
	CThread m_thread;
	CEpoll m_epoll;
	CSocketBase* m_server;
	Buffer m_path;
	FILE* m_file;
};

#ifndef TRACE
#define TRACEI(...) CLoggerServer::Trace(LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_INFO, __VA_AGRS__))
#define TRACED(...) CLoggerServer::Trace(LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_DEBUG, __VA_AGRS__))
#define TRACEW(...) CLoggerServer::Trace(LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_WARNING, __VA_AGRS__))
#define TRACEE(...) CLoggerServer::Trace(LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_ERROR, __VA_AGRS__))
#define TRACEF(...) CLoggerServer::Trace(LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_FATAL, __VA_AGRS__))

//LOGI<<"hello"<<"how are you";
#define LOGI LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_INFO)
#define LOGD LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_DEBUG)
#define LOGW LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_WARNING)
#define LOGE LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_ERROR)
#define LOGF LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_FATAL)

//内存导出
//00 01 02 65……  ; ...a……
//
#define DUMPI(data, size) LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_INFO, data, size)
#define DUMPD(data, size) LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_DEBUG, data, size)
#define DUMPW(data, size) LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_WARNING, data, size)
#define DUMPE(data, size) LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_ERROR, data, size)
#define DUMPF(data, size) LogInfo(__FILE__, __LINE__, __FUNCTION__, getpid(), pthread_self(), LOG_FATAL, data, size)
#endif

```



### 日志模块的测试

主线程中调用

子线程中调用

信号触发时调用

日志中包含整数、小数、字符、字符串

日志中包含英文、中文、标点符号

```c++
int LogTest()
{
	char buffer[] = "hello edoyun! 冯老师";
	usleep(1000 * 100);
	TRACEI("here is log %d %c %f %g %s 哈哈 嘻嘻 易道云", 10, 'A', 1.0f, 2.0, buffer);
	DUMPD((void*)buffer, (size_t)sizeof(buffer));
	LOGE << 100 << " " << 'S' << " " << 0.12345f << " " << 1.23456789 << " " << buffer << " 易道云编程";
	return 0;
}

int main()
{
	//CProcess::SwitchDeamon();
	CProcess proclog, procclients;
	printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
	proclog.SetEntryFunction(CreateLogServer, &proclog);
	int ret = proclog.CreateSubProcess();
	if (ret != 0) {
		printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
		return -1;
	}
	LogTest();
	printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
	CThread thread(LogTest);
	thread.Start();
	procclients.SetEntryFunction(CreateClientServer, &procclients);
	ret = procclients.CreateSubProcess();
	if (ret != 0) {
		printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
		return -2;
	}
	printf("%s(%d):<%s> pid=%d\n", __FILE__, __LINE__, __FUNCTION__, getpid());
	usleep(100 * 000);
	int fd = open("./test.txt", O_RDWR | O_CREAT | O_APPEND);
	printf("%s(%d):<%s> fd=%d\n", __FILE__, __LINE__, __FUNCTION__, fd);
	if (fd == -1)return -3;
	ret = procclients.SendFD(fd);
	printf("%s(%d):<%s> ret=%d\n", __FILE__, __LINE__, __FUNCTION__, ret);
	if (ret != 0)printf("errno:%d msg:%s\n", errno, strerror(errno));
	write(fd, "edoyun", 6);
	close(fd);
	proclog.SendFD(-1);
	(void)getchar();
	return 0;
}
```



### 主模块的设计

主模块主要就是**客户端的接入**，然后*分发客户端到客户端处理进程去处理*

所以其逻辑比较清晰（服务器每个模块的逻辑，越简单越好）

下图展示了程序的流程：

```mermaid
graph TD
A0(开始)-->A1[创建日志服务器进程]
-->A2[创建客户端处理进程]
-->A3[创建网络服务器]
-->A4(结束)
```

网络服务器逻辑则要复杂一点

```mermaid
sequenceDiagram
participant CServer
participant CThreadPool
participant CThread
participant CEpoll
participant CNetSocket
participant CProcess
CServer->>CEpoll:Create()
CServer->>CNetSocket:Init()
CEpoll->>CNetSocket:Add()
CServer->>CThreadPool:Start()
CThreadPool->>CThread:Start()
CThread->>CServer:ThreadFunc()
CServer->>CEpoll:WaitEvents()
CServer->>CNetSocket:Link()
CServer->>CProcess:SendFD()
```

服务器的线程函数主要是接收客户端，然后发送到客户端处理进程进行后续处理。

### 线程池的设计

```mermaid
graph LR
A0(开始)-->A1[构造]
-->A2[启动]
-->A3[添加任务]
-->A4[等待]
-->A5[关闭]
-->A6(结束)
```



接口设计：

```c++
#pragma once
#include "Epoll.h"
#include "Thread.h"
#include "Function.h"

class CThreadPool
{
public:
	CThreadPool() ;
	~CThreadPool() {
		Close();
	}
	CThreadPool(const CThreadPool&) = delete;
	CThreadPool& operator=(const CThreadPool&) = delete;
public:
	int Start(unsigned count);
	void Close();
	template<typename _FUNCTION_, typename... _ARGS_>
	int AddTask(_FUNCTION_ func, _ARGS_... args);
private:
	int TaskDispatch();
private:
	CEpoll m_epoll;
	std::vector<CThread*> m_threads;
	CSocketBase* m_server;
	Buffer m_path;
};
```



### 线程池的实现

```c++
#pragma once
#include "Epoll.h"
#include "Thread.h"
#include "Function.h"
#include "Socket.h"

class CThreadPool
{
public:
	CThreadPool() {
		m_server = NULL;
		timespec tp = { 0,0 };
		clock_gettime(CLOCK_REALTIME, &tp);
		char* buf = NULL;
		asprintf(&buf, "%d.%d.sock", tp.tv_sec % 100000, tp.tv_nsec % 1000000);
		if (buf != NULL) {
			m_path = buf;
			free(buf);
		}//有问题的话，在start接口里面判断m_path来解决问题。
		usleep(1);
	}
	~CThreadPool() {
		Close();
	}
	CThreadPool(const CThreadPool&) = delete;
	CThreadPool& operator=(const CThreadPool&) = delete;
public:
	int Start(unsigned count) {
		int ret = 0;
		if (m_server != NULL)return -1;//已经初始化了
		if (m_path.size() == 0)return -2;//构造函数失败！！！
		m_server = new CLocalSocket();
		if (m_server == NULL)return -3;
		ret = m_server->Init(CSockParam(m_path, SOCK_ISSERVER));
		if (ret != 0)return -4;
		ret = m_epoll.Create(count);
		if (ret != 0)return -5;
		ret = m_epoll.Add(*m_server, EpollData((void*)m_server));
		if (ret != 0)return -6;
		m_threads.resize(count);
		for (unsigned i = 0; i < count; i++) {
			m_threads[i] = new CThread(&CThreadPool::TaskDispatch, this);
			if (m_threads[i] == NULL)return -7;
			ret = m_threads[i]->Start();
			if (ret != 0)return -8;
		}
		return 0;
	}
	void Close() {
		m_epoll.Close();
		if (m_server) {
			CSocketBase* p = m_server;
			m_server = NULL;
			delete p;
		}
		for (auto thread : m_threads)
		{
			if (thread)delete thread;
		}
		m_threads.clear();
		unlink(m_path);
	}
	template<typename _FUNCTION_, typename... _ARGS_>
	int AddTask(_FUNCTION_ func, _ARGS_... args) {
		static thread_local CLocalSocket client;
		int ret = 0;
		if (client == -1) {
			ret = client.Init(CSockParam(m_path, 0));
			if (ret != 0)return -1;
			ret = client.Link();
			if (ret != 0)return -2;
		}
		CFunctionBase* base = new CFunction< _FUNCTION_, _ARGS_...>(func, args...);
		if (base == NULL)return -3;
		Buffer data(sizeof(base));
		memcpy(data, &base, sizeof(base));
		ret = client.Send(data);
		if (ret != 0) {
			delete base;
			return -4;
		}
		return 0;
	}
private:
	int TaskDispatch() {
		while (m_epoll != -1) {
			EPEvents events;
			int ret = 0;
			ssize_t esize = m_epoll.WaitEvents(events);
			if (esize > 0) {
				for (ssize_t i = 0; i < esize; i++) {
					if (events[i].events & EPOLLIN) {
						CSocketBase* pClient = NULL;
						if (events[i].data.ptr == m_server) {//客户端请求连接

							ret = m_server->Link(&pClient);
							if (ret != 0)continue;
							ret = m_epoll.Add(*pClient, EpollData((void*)pClient));
							if (ret != 0) {
								delete pClient;
								continue;
							}
						}
						else {//客户端的数据来了
							pClient = (CSocketBase*)events[i].data.ptr;
							if (pClient) {
								CFunctionBase* base = NULL;
								Buffer data(sizeof(base));
								ret = pClient->Recv(data);
								if (ret <= 0) {
									m_epoll.Del(*pClient);
									delete pClient;
									continue;
								}
								memcpy(&base, (char*)data, sizeof(base));
								if (base != NULL) {
									(*base)();
									delete base;
								}
							}
						}
					}
				}
			}
		}
		return 0;
	}
private:
	CEpoll m_epoll;
	std::vector<CThread*> m_threads;
	CSocketBase* m_server;
	Buffer m_path;
};
```



### 主模块的实现

```mermaid
classDiagram
	CServer ..> CBusiness
	class CBusiness{
		+BusinessProcess()* int
		+setConnected() int
		+setRecvDone() int
		-CFunctionBase* m_connected
		-CFunctionBase* m_recvdone
	}
	class CServer{
		+Init(business,ip="127.0.0.1",port=9999) int
		+Run() int
		+Close() int
		-ThreadFunc() int
		-CThreadPool m_pool
		-CSocketBase* m_server
		-CEpoll m_epoll
		-CProcess m_process
		-CBussiness* m_bussiness
	}
    
```



```mermaid
sequenceDiagram
participant 业务类
participant CServer
participant CBussiness
participant CFunctionBase
业务类->>CServer:Init()
业务类->>CBussiness:setConnected()
业务类->>CBussiness:setRecvDone()
业务类->>CServer:Run()
CServer->>CServer:ThreadFunc()
CServer->>CFunctionBase:m_connected->operator()
CServer->>CFunctionBase:m_recvdone->operator()
业务类->>CServer:Close()
```

CServer.h
```c++
#pragma once
#include "Socket.h"
#include "Epoll.h"
#include "ThreadPool.h"
#include "Process.h"
class CBusiness
{
public:
	virtual int BusinessProcess() = 0;
	template<typename _FUNCTION_, typename... _ARGS_>
	int setConnectedCallback(_FUNCTION_ func, _ARGS_... args) {
		m_connectedcallback = new CFunction< _FUNCTION_, _ARGS_...>(func, args...);
		if (m_connectedcallback == NULL)return -1;
		return 0;
	}
	template<typename _FUNCTION_, typename... _ARGS_>
	int setRecvCallback(_FUNCTION_ func, _ARGS_... args) {
		m_recvcallback = new CFunction< _FUNCTION_, _ARGS_...>(func, args...);
		if (m_recvcallback == NULL)return -1;
		return 0;
	}
private:
	CFunctionBase* m_connectedcallback;
	CFunctionBase* m_recvcallback;
};

class CServer
{
public:
	CServer();
	~CServer() { Close(); }
	CServer(const CServer&) = delete;
	CServer& operator=(const CServer&) = delete;
public:
	int Init(CBusiness* business, const Buffer& ip = "127.0.0.1", short port = 9999);
	int Run();
	int Close();
private:
	int ThreadFunc();
private:
	CThreadPool m_pool;
	CSocketBase* m_server;
	CEpoll m_epoll;
	CProcess m_process;
	CBusiness* m_business;//业务模块 需要我们手动delete
};


```
CServer.cpp
```C++
#include "CServer.h"
#include "Logger.h"

CServer::CServer()
{
	m_server = NULL;
	m_business = NULL;
}

int CServer::Init(CBusiness* business, const Buffer& ip, short port)
{
	int ret = 0;
	if (business == NULL)return -1;
	m_business = business;
	ret = m_process.SetEntryFunction(&CBusiness::BusinessProcess, m_business);
	if (ret != 0)return -2;
	ret = m_process.CreateSubProcess();
	if (ret != 0)return -3;
	ret = m_pool.Start(2);
	if (ret != 0)return -4;
	ret = m_epoll.Create(2);
	if (ret != 0)return -5;
	m_server = new CSocket();
	if (m_server == NULL)return -6;
	ret = m_server->Init(CSockParam(ip, port, SOCK_ISSERVER | SOCK_ISIP));
	if (ret != 0)return -7;
	ret = m_epoll.Add(*m_server, EpollData((void*)m_server));
	if (ret != 0)return -8;
	for (size_t i = 0; i < m_pool.Size(); i++) {
		ret = m_pool.AddTask(&CServer::ThreadFunc, this);
		if (ret != 0)return -9;
	}
	return 0;
}

int CServer::Run()
{
	while (m_server != NULL) {
		usleep(10);
	}
	return 0;
}

int CServer::Close()
{
	if (m_server) {
		CSocketBase* sock = m_server;
		m_server = NULL;
		m_epoll.Del(*sock);
		delete sock;
	}
	m_epoll.Close();
	m_process.SendFD(-1);
	m_pool.Close();
	return 0;
}

int CServer::ThreadFunc()
{
	int ret = 0;
	EPEvents events;
	while ((m_epoll != -1) && (m_server != NULL)) {
		ssize_t size = m_epoll.WaitEvents(events);
		if (size < 0)break;
		if (size > 0) {
			for (ssize_t i = 0; i < size; i++)
			{
				if (events[i].events & EPOLLERR) {
					break;
				}
				else if (events[i].events & EPOLLIN) {
					if (m_server) {
						CSocketBase* pClient = NULL;
						ret = m_server->Link(&pClient);
						if (ret != 0)continue;
						ret = m_process.SendFD(*pClient);
						delete pClient;
						if (ret != 0) {
							TRACEE("send client %d failed!", (int)*pClient);
							continue;
						}
					}
				}
			}
		}
	}
	return 0;
}

```


### 客户端处理模块的设计

```mermaid
classDiagram
	CBusiness <|.. CEdoyunPlayerServer:接口实现
	class CBusiness{
		<<interface>>
		+BusinessProcess()* int
		+setConnected() int
		+setRecvDone() int
		-CFunctionBase* m_connected
		-CFunctionBase* m_recvdone
	}
	class CEdoyunPlayerServer{
		+BusinessProcess()* int
		-ThreadFunc()
		-CEpoll m_epoll
		-CThreadPool m_pool
		-map~int,CSocket*~ m_mapClients
	}

```

基本流程图

```mermaid
graph TD
S(开始)-->A0[开启线程池]
A0-->B0
A0-->A1[等待客户端]
-->A2[添加到epoll]
-->A3[检测状态]
A3-->E(结束)
A3-->A1
subgraph 客户端处理线程
B0[等待epoll事件]-->
B1[处理读取事件]-->
B2[调用业务回调函数]-->B0
end
```



### 客户端处理模块的实现

CEdoyunPlayerServer.h


```c++
#pragma once
#include "Logger.h"
#include "CServer.h"
#include <map>
/*
* 1. 客户端的地址问题
* 2. 连接回调的参数问题
* 3. 接收回调的参数问题
*/
#define ERR_RETURN(ret, err) if(ret!=0){TRACEE("ret= %d errno = %d msg = [%s]", ret, errno, strerror(errno));return err;}

#define WARN_CONTINUE(ret) if(ret!=0){TRACEW("ret= %d errno = %d msg = [%s]", ret, errno, strerror(errno));continue;}

class CEdoyunPlayerServer :
	public CBusiness
{
public:
	CEdoyunPlayerServer(unsigned count) :CBusiness() {
		m_count = count;
	}
	~CEdoyunPlayerServer() {
		m_epoll.Close();
		m_pool.Close();
		for (auto it : m_mapClients) {
			if (it.second) {
				delete it.second;
			}
		}
		m_mapClients.clear();
	}
	virtual int BusinessProcess(CProcess* proc) {
		int ret = 0;
		ret = m_epoll.Create(m_count);
		ERR_RETURN(ret, -1);
		ret = m_pool.Start(m_count);
		ERR_RETURN(ret, -2);
		for (unsigned i = 0; i < m_count; i++) {
			ret = m_pool.AddTask(&CEdoyunPlayerServer::ThreadFunc, this);
			ERR_RETURN(ret, -3);
		}
		int sock = 0;
		setRecvCallback(&CEdoyunPlayerServer::RecvDone, this, std::placeholders::_1, std::placeholders::_2);
		setConnectedCallback(&CEdoyunPlayerServer::ConnectedDone, this, std::placeholders::_1);
		while (m_epoll != -1) {
			ret = proc->RecvFD(sock);
			if (ret < 0 || (sock == 0))break;
			CSocketBase* pClient = new CSocket(sock);
			if (pClient == NULL)continue;
			ret = m_epoll.Add(sock, EpollData((void*)pClient));
			if (m_connectedcallback) {
				(*m_connectedcallback)(pClient);
			}
			WARN_CONTINUE(ret);
		}
		return 0;
	}
private:
	int ConnectedDone(CSocketBase* pClient) {
		return 0;
	}
	int RecvDone(CSocketBase* pClient, const Buffer& data) {
		return 0;
	}
private:
	int ThreadFunc() {
		int ret = 0;
		EPEvents events;
		while (m_epoll != -1) {
			ssize_t size = m_epoll.WaitEvents(events);
			if (size < 0)break;
			if (size > 0) {
				for (ssize_t i = 0; i < size; i++)
				{
					if (events[i].events & EPOLLERR) {
						break;
					}
					else if (events[i].events & EPOLLIN) {
						CSocketBase* pClient = (CSocketBase*)events[i].data.ptr;
						if (pClient) {
							Buffer data;
							ret = pClient->Recv(data);
							WARN_CONTINUE(ret);
							if (m_recvcallback) {
								(*m_recvcallback)(pClient, data);
							}
						}
					}
				}
			}
		}
		return 0;
	}
private:
	CEpoll m_epoll;
	std::map<int, CSocketBase*> m_mapClients;
	CThreadPool m_pool;
	unsigned m_count;
};
```

Function.h

```c++
#pragma once
#include <unistd.h>
#include <sys/types.h>
#include <functional>

class CSocketBase;
class Buffer;

class CFunctionBase
{
public:
	virtual ~CFunctionBase() {}
	virtual int operator()() { return 0; }
	virtual int operator()(CSocketBase*) { return 0; }
	virtual int operator()(CSocketBase*, const Buffer&) { return 0; }
};

template<typename _FUNCTION_, typename... _ARGS_>
class CFunction :public CFunctionBase
{
public:
	CFunction(_FUNCTION_ func, _ARGS_... args)
		:m_binder(std::forward<_FUNCTION_>(func), std::forward<_ARGS_>(args)...)
	{}
	virtual ~CFunction() {}
	virtual int operator()() {
		return m_binder();
	}

	typename std::_Bindres_helper<int, _FUNCTION_, _ARGS_...>::type m_binder;
};

template<typename _FUNCTION_, typename... _ARGS_>
class CConnectedFunction :public CFunctionBase
{
public:
	CConnectedFunction(_FUNCTION_ func, _ARGS_... args)
		:m_binder(std::forward<_FUNCTION_>(func), std::forward<_ARGS_>(args)...)
	{}
	virtual ~CConnectedFunction() {}
	
	virtual int operator()(CSocketBase* pClient) {
		return m_binder(pClient);
	}

	typename std::_Bindres_helper<int, _FUNCTION_, _ARGS_...>::type m_binder;
};

template<typename _FUNCTION_, typename... _ARGS_>
class CRecvFunction :public CFunctionBase
{
public:
	CRecvFunction(_FUNCTION_ func, _ARGS_... args)
		:m_binder(std::forward<_FUNCTION_>(func), std::forward<_ARGS_>(args)...)
	{}
	virtual ~CRecvFunction() {}

	virtual int operator()(CSocketBase* pClient, const Buffer& data) {
		return m_binder(pClient, data);
	}
	
	typename std::_Bindres_helper<int, _FUNCTION_, _ARGS_...>::type m_binder;
};
```



### HTTP模块的设计

**封装的作用**

* 降低使用成本
* 对外屏蔽细节（**低耦合**）
* 增加可以移植性
* 与更多同类数据关联（**高内聚**）

```mermaid
classDiagram
class CHttpParser{
	-http_parser m_parser
	-http_parser_settings m_settings
	-map<std::string, std::string> m_HeaderValues
	-string m_status
	-string m_url
	-string m_body
	-bool m_complete
	#string m_lastField
	+CHttpParser()
	+~CHttpParser()
	+CHttpParser(const CHttpParser& http)
	+Parser(const vector<char>& data) size_t
	+Parser(const string& data) size_t
	+Method() const unsigned
	+Headers() map~string,string~
	+Status() string
	+Url() string
	+Body() string
	+Errno() const unsigned
	#OnMessageBegin(http_parser* parser)$ int
	#OnHeaderField(http_parser* parser,const char* at,size_t length)$ int
	#OnHeaderValue(http_parser* parser,const char* at,size_t length)$ int
	#OnUrl(http_parser* parser,const char* at,size_t length)$ int
	#OnStatus(http_parser* parser,const char* at,size_t length)$ int
	#OnBody(http_parser* parser,const char* at,size_t length)$ int
	#OnHeadersComplete(http_parser* parser)$ int
	#OnMessageComplete(http_parser* parser)$ int
	#OnMessageBegin() int
	#OnHeaderField(const char* at,size_t length) int
	#OnHeaderValue(const char* at,size_t length) int
	#OnUrl(const char* at,size_t length) int
	#OnStatus(const char* at,size_t length) int
	#OnBody(const char* at,	size_t length) int
	#OnHeadersComplete() int
	#OnMessageComplete() int
}

class TParseUrl{
	#CompareStr(const char* pos, const char* compare, size_t& clen)$ int
	#FindStr(const char* u, const char* compare)$ int
	#FindStrPos(const char* u, const char* compare)$ const char*
	#ParseDomain(const char* pos, const char* posend, TUrlParam& param)$ int
	#IsNumber(const char* num)$ bool
	+TParseUrl(const std::string& url)
	+~TParseUrl()* 
	+TUrlParam v_param
	+ParseUrl(const std::string& url, TUrlParam& param)$ int
	+GetParam(const std::string& param) std::string
	+SetUrl(const std::string& url) void
}

```

```mermaid
graph TD
A0(调用)-->A1[CHttpParser]
-->A2[http_parser]
```









### HTTP模块的实现

HttpParser.h

```c++
#pragma once
#include "Socket.h"
#include "http_parser.h"
#include <map>

class CHttpParser
{
private:
	http_parser m_parser;
	http_parser_settings m_settings;
	std::map<Buffer, Buffer> m_HeaderValues;
	Buffer m_status;
	Buffer m_url;
	Buffer m_body;
	bool m_complete;
	Buffer m_lastField;
public:
	CHttpParser();
	~CHttpParser();
	CHttpParser(const CHttpParser& http);
	CHttpParser& operator=(const CHttpParser& http);
public:
	size_t Parser(const Buffer& data);
	//GET POST ... 参考http_parser.h HTTP_METHOD_MAP宏
	unsigned Method() const { return m_parser.method; }
	const std::map<Buffer, Buffer>& Headers() { return m_HeaderValues; }
	const Buffer& Status() const { return m_status; }
	const Buffer& Url() const { return m_url; }
	const Buffer& Body() const { return m_body; }
	unsigned Errno() const { return m_parser.http_errno; }
protected:
	static int OnMessageBegin(http_parser* parser);
	static int OnUrl(http_parser* parser, const char* at, size_t length);
	static int OnStatus(http_parser* parser, const char* at, size_t length);
	static int OnHeaderField(http_parser* parser, const char* at, size_t length);
	static int OnHeaderValue(http_parser* parser, const char* at, size_t length);
	static int OnHeadersComplete(http_parser* parser);
	static int OnBody(http_parser* parser, const char* at, size_t length);
	static int OnMessageComplete(http_parser* parser);
	int OnMessageBegin();
	int OnUrl(const char* at, size_t length);
	int OnStatus(const char* at, size_t length);
	int OnHeaderField(const char* at, size_t length);
	int OnHeaderValue(const char* at, size_t length);
	int OnHeadersComplete();
	int OnBody(const char* at, size_t length);
	int OnMessageComplete();
};

class UrlParser
{
public:
	UrlParser(const Buffer& url);
	~UrlParser() {}
	int Parser();
	Buffer operator[](const Buffer& name)const;
	Buffer Protocol()const { return m_protocol; }
	Buffer Host()const { return m_host; }
	//默认返回80
	int Port()const { return m_port; }
	void SetUrl(const Buffer& url);
private:
	Buffer m_url;
	Buffer m_protocol;
	Buffer m_host;
	Buffer m_uri;
	int m_port;
	std::map<Buffer, Buffer> m_values;
};
```

HttpParser.cpp

```c++
#include "HttpParser.h"

CHttpParser::CHttpParser()
{
	m_complete = false;
	memset(&m_parser, 0, sizeof(m_parser));
	m_parser.data = this;
	http_parser_init(&m_parser, HTTP_REQUEST);
	memset(&m_settings, 0, sizeof(m_settings));
	m_settings.on_message_begin = &CHttpParser::OnMessageBegin;
	m_settings.on_url = &CHttpParser::OnUrl;
	m_settings.on_status = &CHttpParser::OnStatus;
	m_settings.on_header_field = &CHttpParser::OnHeaderField;
	m_settings.on_header_value = &CHttpParser::OnHeaderValue;
	m_settings.on_headers_complete = &CHttpParser::OnHeadersComplete;
	m_settings.on_body = &CHttpParser::OnBody;
	m_settings.on_message_complete = &CHttpParser::OnMessageComplete;
}

CHttpParser::~CHttpParser()
{}

CHttpParser::CHttpParser(const CHttpParser& http)
{
	memcpy(&m_parser, &http.m_parser, sizeof(m_parser));
	m_parser.data = this;
	memcpy(&m_settings, &http.m_settings, sizeof(m_settings));
	m_status = http.m_status;
	m_url = http.m_url;
	m_body = http.m_body;
	m_complete = http.m_complete;
	m_lastField = http.m_lastField;
}

CHttpParser& CHttpParser::operator=(const CHttpParser& http)
{
	if (this != &http) {
		memcpy(&m_parser, &http.m_parser, sizeof(m_parser));
		m_parser.data = this;
		memcpy(&m_settings, &http.m_settings, sizeof(m_settings));
		m_status = http.m_status;
		m_url = http.m_url;
		m_body = http.m_body;
		m_complete = http.m_complete;
		m_lastField = http.m_lastField;
	}
	return *this;
}

size_t CHttpParser::Parser(const Buffer& data)
{
	m_complete = false;
	size_t ret = http_parser_execute(
		&m_parser, &m_settings, data, data.size());
	if (m_complete == false) {
		m_parser.http_errno = 0x7F;
		return 0;
	}
	return ret;
}

int CHttpParser::OnMessageBegin(http_parser* parser)
{
	return ((CHttpParser*)parser->data)->OnMessageBegin();
}

int CHttpParser::OnUrl(http_parser* parser, const char* at, size_t length)
{
	return ((CHttpParser*)parser->data)->OnUrl(at, length);
}

int CHttpParser::OnStatus(http_parser* parser, const char* at, size_t length)
{
	return ((CHttpParser*)parser->data)->OnStatus(at, length);
}

int CHttpParser::OnHeaderField(http_parser* parser, const char* at, size_t length)
{
	return ((CHttpParser*)parser->data)->OnHeaderField(at, length);
}

int CHttpParser::OnHeaderValue(http_parser* parser, const char* at, size_t length)
{
	return ((CHttpParser*)parser->data)->OnHeaderValue(at, length);
}

int CHttpParser::OnHeadersComplete(http_parser* parser)
{
	return ((CHttpParser*)parser->data)->OnHeadersComplete();
}

int CHttpParser::OnBody(http_parser* parser, const char* at, size_t length)
{
	return ((CHttpParser*)parser->data)->OnBody(at, length);
}

int CHttpParser::OnMessageComplete(http_parser* parser)
{
	return ((CHttpParser*)parser->data)->OnMessageComplete();
}

int CHttpParser::OnMessageBegin()
{
	return 0;
}

int CHttpParser::OnUrl(const char* at, size_t length)
{
	m_url = Buffer(at, length);
	return 0;
}

int CHttpParser::OnStatus(const char* at, size_t length)
{
	m_status = Buffer(at, length);
	return 0;
}

int CHttpParser::OnHeaderField(const char* at, size_t length)
{
	m_lastField = Buffer(at, length);
	return 0;
}

int CHttpParser::OnHeaderValue(const char* at, size_t length)
{
	m_HeaderValues[m_lastField] = Buffer(at, length);
	return 0;
}

int CHttpParser::OnHeadersComplete()
{
	return 0;
}

int CHttpParser::OnBody(const char* at, size_t length)
{
	m_body = Buffer(at, length);
	return 0;
}

int CHttpParser::OnMessageComplete()
{
	m_complete = true;
	return 0;
}

UrlParser::UrlParser(const Buffer& url)
{
	m_url = url;
}

int UrlParser::Parser()
{
	//分三步：协议、域名和端口、uri、键值对
	//解析协议
	const char* pos = m_url;
	const char* target = strstr(pos, "://");
	if (target == NULL)return -1;
	m_protocol = Buffer(pos, target);
	//解析域名和端口
	pos = target + 3;
	target = strchr(pos, '/');
	if (target == NULL) {
		if (m_protocol.size() + 3 >= m_url.size())
			return -2;
		m_host = pos;
		return 0;
	}
	Buffer value = Buffer(pos, target);
	if (value.size() == 0)return -3;
	target = strchr(value, ':');
	if (target != NULL) {
		m_host = Buffer(value, target);
		m_port = atoi(Buffer(target + 1, (char*)value + value.size()));
	}
	else {
		m_host = value;
	}
	pos = strchr(pos, '/');
	//解析uri
	target = strchr(pos, '?');
	if (target == NULL) {
		m_uri = pos;
		return 0;
	}
	else {
		m_uri = Buffer(pos, target);
		//解析key和value
		pos = target + 1;
		const char* t = NULL;
		do {
			target = strchr(pos, '&');
			if (target == NULL) {
				t = strchr(pos, '=');
				if (t == NULL)return -4;
				m_values[Buffer(pos, t)] = Buffer(t + 1);
			}
			else {
				Buffer kv(pos, target);
				t = strchr(kv, '=');
				if (t == NULL)return -5;
				m_values[Buffer(kv, t)] = Buffer(t + 1, kv + kv.size());
				pos = target + 1;
			}
		} while (target != NULL);
	}

	return 0;
}

Buffer UrlParser::operator[](const Buffer& name) const
{
	auto it = m_values.find(name);
	if (it == m_values.end())return Buffer();
	return it->second;
}

void UrlParser::SetUrl(const Buffer& url)
{
	m_url = url;
	m_protocol = "";
	m_host = "";
	m_port = 80;
	m_values.clear();
}

```



### 数据库模块的设计

```mermaid
classDiagram
DataBaseClient <|-- Sqlite3Client
DataBaseClient <|-- MysqlClient
class DataBaseClient{
	Connect(args)* int
	Exec(sql)* int
	Exec(sql,result)* int
	StartTransaction()* int
	CommitTransaction()* int
	RollabckTransaction()* int
	IsConnected()* bool
	Close()* int
}
class Sqlite3Client{
	Connect(args)* int
	Exec(sql)* int
	Exec(sql,result)* int
	StartTransaction()* int
	CommitTransaction()* int
	RollabckTransaction()* int
	IsConnected()* bool
	Close()* int
}
class MysqlClient{
	Connect(args)* int
	Exec(sql)* int
	Exec(sql,result)* int
	StartTransaction()* int
	CommitTransaction()* int
	RollabckTransaction()* int
	IsConnected()* bool
	Close()* int
}
```

数据库的基本流程：

```mermaid
graph TD
A0[Connect]-->A1[Exec]
-->A2[处理结果]
-->A3[Close]
B0[Connect]-->B1[StartTransaction]
-->B2[Exec]
-->B3[CommitTransaction]
-->B4[Close]
```

数据类的设计：

```mermaid
classDiagram
_Table_ o-- _Field_
_Table_ <|-- _Sqlite3_Table_
_Table_ <|-- _Mysql_Table_
_Field_ <|-- _DeclareMysqlField~T~
_Field_ <|-- _DeclareMysqlField~void~
_Field_ <|-- _DeclareSqlite3Field~T~
_Field_ <|-- _DeclareSqlite3Field~void~
_DeclareSqlite3Field~T~ <|-- _sqlite3_INTEGER_FILED
_DeclareSqlite3Field~void~ <|-- _sqlite3_NULL_FILED
_DeclareMysqlField~void~ <|-- _mysql_NULL_FILED
_DeclareMysqlField~T~ <|-- _mysql_INTEGER_FILED
class _Field_{
	+FromString(str)* void
	+toEqualExp()* String
	+FullName()* String
	+toString()* String
	+String Name
    +String Type
    +String Size
    +unsigned Attr
    +String Default
    +String Check
}
class _Table_{
	+Create()* String
	+Insert(const SLParam& Columns, const SLParam& Values)* String
	+Drop()* String
	+Modify(const SLParam& Columns, const SLParam& Values)* String
	+Query()* String
	+FullName()const* String
	+Copy()* shared_ptr~_Table_~
	+String Database
	+String Name
	+FieldArray Columns
	+FieldMap Fields
}
```

利用宏，对数据表的快速定义：

```c++
#define DECLARE_TABLE_CLASS(name, base) \
class name:public base { \
public: \
virtual PTable Copy() const{ return PTable(new name(*this));} \
name():base(){Name = _T(#name);

#define DECLARE_ITEM(name, attr, type, size, Default, check) \
{PField field(new type(_T(#name), attr, _T(size), _T(Default), _T(check))); \
Columns.push_back(field); \
Fields.insert(std::pair<String,PField>(_T(#name),field));}

#define DECLARE_TABLE_CLASS_END() }};

DECLARE_TABLE_CLASS(edoyunLogin_user_mysql, _Mysql_Table_)
DECLARE_ITEM(user_id, NOT_NULL | PRIMARY_KEY | AUTOINCREMENT, INTEGER_FILED, "", "", "")
DECLARE_ITEM(user_qq, NOT_NULL, VARCHAR_FILED, "(15)", "", "")  //QQ号
DECLARE_ITEM(user_phone, DEFAULT, VARCHAR_FILED, "(11)", "'18888888888'", "")  //手机
DECLARE_ITEM(user_name, NOT_NULL, TEXT_FILED, "", "", "")    //姓名
DECLARE_ITEM(user_nick, NOT_NULL, TEXT_FILED, "", "", "")    //昵称
DECLARE_ITEM(user_wechat, DEFAULT, TEXT_FILED, "", "NULL", "")
DECLARE_ITEM(user_wechat_id, DEFAULT, TEXT_FILED, "", "NULL", "")
DECLARE_ITEM(user_address, DEFAULT, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_province, DEFAULT, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_country, DEFAULT, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_age, DEFAULT | CHECK, INTEGER_FILED, "", "18", "")
DECLARE_ITEM(user_male, DEFAULT, BOOL_FILED, "", "1", "")
DECLARE_ITEM(user_flags, DEFAULT, TEXT_FILED, "", "0", "")
DECLARE_ITEM(user_experience, DEFAULT, REAL_FILED, "", "0.0", "")
DECLARE_ITEM(user_level, DEFAULT | CHECK, INTEGER_FILED, "", "0", "")
DECLARE_ITEM(user_class_priority, DEFAULT, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_time_per_viewer, DEFAULT, REAL_FILED, "", "", "")
DECLARE_ITEM(user_career, NONE, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_password, NOT_NULL, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_birthday, NONE, DATETIME_FILED, "", "", "")
DECLARE_ITEM(user_describe, NONE, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_education, NONE, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_register_time, DEFAULT, DATETIME_FILED, "", "LOCALTIME()", "")
DECLARE_TABLE_CLASS_END()
    
DECLARE_TABLE_CLASS(edoyunLogin_user_test, _Sqlite3_Table_)
DECLARE_ITEM(user_id, NOT_NULL | PRIMARY_KEY | AUTOINCREMENT, INTEGER_FILED, "", "", "")
DECLARE_ITEM(user_qq, NOT_NULL, VARCHAR_FILED, "(15)", "", "")  //QQ号
DECLARE_ITEM(user_phone, DEFAULT, TEXT_FILED, "", "18888888888", "")  //手机
DECLARE_ITEM(user_name, NOT_NULL, TEXT_FILED, "", "", "")    //姓名
DECLARE_ITEM(user_nick, NOT_NULL, TEXT_FILED, "", "", "")    //昵称
DECLARE_ITEM(user_wechat, DEFAULT, TEXT_FILED, "", "none", "")
DECLARE_ITEM(user_wechat_id, DEFAULT, TEXT_FILED, "", "none", "")
DECLARE_ITEM(user_address, DEFAULT, TEXT_FILED, "", "\"长安大街1号\"", "")
DECLARE_ITEM(user_province, DEFAULT, TEXT_FILED, "", "\"北京\"", "")
DECLARE_ITEM(user_country, DEFAULT, TEXT_FILED, "", "\"中国\"", "")
DECLARE_ITEM(user_age, DEFAULT | CHECK, INTEGER_FILED, "", "18", "\"user_age\" >= 0")
DECLARE_ITEM(user_male, DEFAULT, BOOL_FILED, "", "1", "")
DECLARE_ITEM(user_flags, DEFAULT, TEXT_FILED, "", "0", "")
DECLARE_ITEM(user_experience, DEFAULT, REAL_FILED, "", "0.0", "")
DECLARE_ITEM(user_level, DEFAULT | CHECK, INTEGER_FILED, "", "0", "\"user_level\" >= 0")
DECLARE_ITEM(user_class_priority, DEFAULT, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_time_per_viewer, DEFAULT, REAL_FILED, "", "", "")
DECLARE_ITEM(user_career, NONE, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_password, NOT_NULL, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_birthday, NONE, DATETIME_FILED, "", "", "")
DECLARE_ITEM(user_describe, NONE, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_education, NONE, TEXT_FILED, "", "", "")
DECLARE_ITEM(user_register_time, DEFAULT, DATETIME_FILED, "", "(datetime('now', 'localtime'))", "")
DECLARE_TABLE_CLASS_END()

```

### sqlite3数据库的实现

DataBaseHelper.h

```c++
```

DataBaseHelper.cpp

```c++
```



Sqlite3Client.h

```c++
```

Sqlite3Client.cpp

```c++
```



### MySQL数据库的实现

MysqlClient.h

```c++
```

MysqlClient.cpp

```c++
```



### 加密模块的设计与实现

考虑到加密模块使用的方便性，工具类更合适，原因如下

* 无需声明对象
* 方法既可以相互独立，也可以相互关联
* 随取随用，无需配置或者初始化

OpenSSLHelper.h

```c++


```

OpenSSLHelper.cpp

```c++
```

### 业务功能的实现

业务流程

```mermaid
graph TD
A0(开始)-->A1[客户端连接]
-->A2[客户端请求登录]
-->A3[查询客户账户密码]
-->A4[验证账户密码]
-->A5[返回结果]
-->A6(结束)
```

业务的实现

```c++
```





## 项目测试

### 测试的设计

### 功能的设计

### 功能设计的实现

### 性能的设计

### 性能测试的实现

