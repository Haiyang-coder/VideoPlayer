#pragma once
#include "Public.h"

class Crypto
{
public:
	static Buffer MD5(const Buffer& text);
};

