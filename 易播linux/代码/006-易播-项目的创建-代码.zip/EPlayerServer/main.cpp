﻿#include <cstdio>

int main()
{
    printf("%s 向你问好!\n", "EPlayerServer");
    return 0;
}