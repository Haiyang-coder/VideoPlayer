#include "MysqlClient.h"

int CMysqlClient::Connect(const KeyValue& args)
{
	return 0;
}

int CMysqlClient::Exec(const Buffer& sql)
{
	return 0;
}

int CMysqlClient::Exec(const Buffer& sql, Result& result, const _Table_& table)
{
	return 0;
}

int CMysqlClient::StartTransaction()
{
	return 0;
}

int CMysqlClient::CommitTransaction()
{
	return 0;
}

int CMysqlClient::RollbackTransaction()
{
	return 0;
}

int CMysqlClient::Close()
{
	return 0;
}

bool CMysqlClient::IsConnected()
{
	return false;
}

_mysql_table_::_mysql_table_(const _mysql_table_& table)
{
}

_mysql_table_::~_mysql_table_()
{
}

Buffer _mysql_table_::Create()
{
	return Buffer();
}

Buffer _mysql_table_::Drop()
{
	return Buffer();
}

Buffer _mysql_table_::Insert(const _Table_& values)
{
	return Buffer();
}

Buffer _mysql_table_::Delete(const _Table_& values)
{
	return Buffer();
}

Buffer _mysql_table_::Modify(const _Table_& values)
{
	return Buffer();
}

Buffer _mysql_table_::Query()
{
	return Buffer();
}

PTable _mysql_table_::Copy() const
{
	return PTable();
}

void _mysql_table_::ClearFieldUsed()
{
}

_mysql_table_::operator const Buffer() const
{
	return Buffer();
}

_mysql_field_::_mysql_field_()
{
}

_mysql_field_::_mysql_field_(int ntype, const Buffer& name, unsigned attr, const Buffer& type, const Buffer& size, const Buffer& default_, const Buffer& check)
{
}

_mysql_field_::_mysql_field_(const _mysql_field_& field)
{
}

_mysql_field_::~_mysql_field_()
{
}

Buffer _mysql_field_::Create()
{
	return Buffer();
}

void _mysql_field_::LoadFromStr(const Buffer& str)
{
}

Buffer _mysql_field_::toEqualExp() const
{
	return Buffer();
}

Buffer _mysql_field_::toSqlStr() const
{
	return Buffer();
}

_mysql_field_::operator const Buffer() const
{
	return Buffer();
}

Buffer _mysql_field_::Str2Hex(const Buffer& data) const
{
	return Buffer();
}
