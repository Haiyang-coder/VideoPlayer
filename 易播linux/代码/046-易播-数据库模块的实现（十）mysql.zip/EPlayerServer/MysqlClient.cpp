#include "MysqlClient.h"

int CMysqlClient::Connect(const KeyValue& args)
{
	if (m_bInit)return -1;
	MYSQL* ret = mysql_init(&m_db);
	if (ret == NULL)return -2;
	ret = mysql_real_connect(&m_db,
		args.at("host"), args.at("user"),
		args.at("password"), args.at("db"),
		atoi(args.at("port")),
		NULL, 0);
	if ((ret == NULL) && (mysql_errno(&m_db) != 0)) {
		printf("%s %s\n", __FUNCTION__, mysql_errno(&m_db));
		mysql_close(&m_db);
		bzero(&m_db, sizeof(m_db));
		return -3;
	}
	m_bInit = true;
	return 0;
}

int CMysqlClient::Exec(const Buffer& sql)
{
	if (!m_bInit)return -1;
	int ret = mysql_real_query(&m_db, sql, sql.size());
	if (ret != 0) {
		printf("%s %s\n", __FUNCTION__, mysql_errno(&m_db));
		return -2;
	}
	return 0;
}

int CMysqlClient::Exec(const Buffer& sql, Result& result, const _Table_& table)
{
	if (!m_bInit)return -1;
	int ret = mysql_real_query(&m_db, sql, sql.size());
	if (ret != 0) {
		printf("%s %s\n", __FUNCTION__, mysql_errno(&m_db));
		return -2;
	}
	MYSQL_RES* res = mysql_store_result(&m_db);
	MYSQL_ROW row;
	unsigned num_fields = mysql_num_fields(res);
	while ((row = mysql_fetch_row(res)) != NULL) {
		PTable pt = table.Copy();
		for (unsigned i = 0; i < num_fields; i++) {
			if (row[i] != NULL) {
				pt->FieldDefine[i]->LoadFromStr(row[i]);
			}
		}
		result.push_back(pt);
	}
	return 0;
}

int CMysqlClient::StartTransaction()
{
	if (!m_bInit)return -1;
	int ret = mysql_real_query(&m_db, "BEGIN", 6);
	if (ret != 0) {
		printf("%s %s\n", __FUNCTION__, mysql_errno(&m_db));
		return -2;
	}
	return 0;
}

int CMysqlClient::CommitTransaction()
{
	if (!m_bInit)return -1;
	int ret = mysql_real_query(&m_db, "COMMIT", 7);
	if (ret != 0) {
		printf("%s %s\n", __FUNCTION__, mysql_errno(&m_db));
		return -2;
	}
	return 0;
}

int CMysqlClient::RollbackTransaction()
{
	if (!m_bInit)return -1;
	int ret = mysql_real_query(&m_db, "ROLLBACK", 9);
	if (ret != 0) {
		printf("%s %s\n", __FUNCTION__, mysql_errno(&m_db));
		return -2;
	}
	return 0;
}

int CMysqlClient::Close()
{
	if (m_bInit) {
		m_bInit = false;
		mysql_close(&m_db);
		bzero(&m_db, sizeof(m_db));
	}
	return 0;
}

bool CMysqlClient::IsConnected()
{
	return m_bInit;
}

_mysql_table_::_mysql_table_(const _mysql_table_& table)
{
}

_mysql_table_::~_mysql_table_()
{
}

Buffer _mysql_table_::Create()
{
	return Buffer();
}

Buffer _mysql_table_::Drop()
{
	return Buffer();
}

Buffer _mysql_table_::Insert(const _Table_& values)
{
	return Buffer();
}

Buffer _mysql_table_::Delete(const _Table_& values)
{
	return Buffer();
}

Buffer _mysql_table_::Modify(const _Table_& values)
{
	return Buffer();
}

Buffer _mysql_table_::Query()
{
	return Buffer();
}

PTable _mysql_table_::Copy() const
{
	return PTable();
}

void _mysql_table_::ClearFieldUsed()
{
}

_mysql_table_::operator const Buffer() const
{
	return Buffer();
}

_mysql_field_::_mysql_field_()
{
}

_mysql_field_::_mysql_field_(int ntype, const Buffer& name, unsigned attr, const Buffer& type, const Buffer& size, const Buffer& default_, const Buffer& check)
{
}

_mysql_field_::_mysql_field_(const _mysql_field_& field)
{
}

_mysql_field_::~_mysql_field_()
{
}

Buffer _mysql_field_::Create()
{
	return Buffer();
}

void _mysql_field_::LoadFromStr(const Buffer& str)
{
}

Buffer _mysql_field_::toEqualExp() const
{
	return Buffer();
}

Buffer _mysql_field_::toSqlStr() const
{
	return Buffer();
}

_mysql_field_::operator const Buffer() const
{
	return Buffer();
}

Buffer _mysql_field_::Str2Hex(const Buffer& data) const
{
	return Buffer();
}
